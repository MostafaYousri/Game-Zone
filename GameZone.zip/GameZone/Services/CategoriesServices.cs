﻿
using Microsoft.EntityFrameworkCore;

namespace GameZone.Services
{
    public class CategoriesServices : ICategoriesServices
    {
        private readonly ApplicationDBContext _dBContext;

        public CategoriesServices(ApplicationDBContext dBContext)
        {
            _dBContext = dBContext;
        }
        public IEnumerable<SelectListItem> GetSelectList()
        {
            return _dBContext.Categories
                .Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name })
                .OrderBy(c => c.Text)
                .ToList();
        }
    }
}

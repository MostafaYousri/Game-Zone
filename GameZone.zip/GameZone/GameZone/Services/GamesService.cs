﻿
namespace GameZone.Services
{
    public class GamesService : IGamesService
    {
        private readonly ApplicationDBContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly string _imagesPath;
        public GamesService(ApplicationDBContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
           _webHostEnvironment = webHostEnvironment;
            _imagesPath = $"{_webHostEnvironment.WebRootPath}{FileSettings.ImagesPath}";
        }
        public IEnumerable<Game> GetAll()
        {
            return _context.Games
                .Include(g=> g.Category)
                .Include(d => d.Devices)
                .ThenInclude(d => d.Device)
                .AsNoTracking().ToList();
        }
        public Game? GetById(int Id)
         {
            return _context.Games
                .Include(g => g.Category)
                .Include(d => d.Devices)
                .ThenInclude(d => d.Device)
                .AsNoTracking().SingleOrDefault(g => g.Id == Id);
        }
        public async Task Create(CreateGameFormViewModel model)
        {
            var covername = await SaveCover(model.Cover);

            Game game = new()
            {
                Name = model.Name,
                Cover = covername,
                Description = model.Description,
                CategoryId = model.CategoryId,
                Devices = model.SelectedDevices.Select(d => new GameDevice { DeviceId =d}).ToList()
            };

            _context.Add(game);
            _context.SaveChanges();
        }

        public async Task<Game?> Update(EditGameFormViewModel model)
        {
            var game = _context.Games
                .Include(d => d.Devices)
                .SingleOrDefault(g => g.Id == model.Id);

            if (game is null) return null;

            var hasNewCover = model.Cover is not null;
            var oldCover = game.Cover;

            game.Name = model.Name; 
            game.Description = model.Description;
            game.CategoryId = model.CategoryId;
            game.Devices = model.SelectedDevices.Select(d =>new GameDevice { DeviceId =d}).ToList();

            if (hasNewCover) 
                game.Cover = await SaveCover(model.Cover!);
            var effectedRows =_context.SaveChanges();
            if (effectedRows > 0)
            {
                if (hasNewCover)
                {
                    var cover = Path.Combine(_imagesPath, oldCover);
                    File.Delete(cover);
                }
                return game;
            }
            var Newcover = Path.Combine(_imagesPath, game.Cover);
            File.Delete(Newcover);
            return null;    
        }
        public bool Delete(int Id)
        {
            var game = _context.Games.Find(Id);

            if (game is null) return false;
            _context.Games.Remove(game);
            var effectedRows = _context.SaveChanges();
            if (effectedRows > 0)
            {
                var cover = Path.Combine(_imagesPath, game.Cover);
                File.Delete(cover);
                return true;
            }
            return false;
        }
        private async Task<string> SaveCover(IFormFile cover)
        {
            var covername = $"{Guid.NewGuid()}{Path.GetExtension(cover.FileName)}";
            var CoverPath = Path.Combine(_imagesPath, covername);

            using var stream = File.Create(CoverPath);
            await cover.CopyToAsync(stream);
            return covername;

        }


    }
}

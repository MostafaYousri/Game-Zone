﻿


using System.Threading.Tasks;

namespace GameZone.Controllers
{
    public class GamesController : Controller
    {
        private readonly ICategoriesServices _categoriesServices;
        private readonly IDevicesServices _devicesServices;
        private readonly IGamesService _gamesService;

        public GamesController(ICategoriesServices categoriesServices
                                ,IDevicesServices devicesServices,IGamesService gamesServices)
        {
            
            _categoriesServices = categoriesServices;
            _devicesServices = devicesServices;
            _gamesService = gamesServices;
        }

        public IActionResult Index()
        {
            var games = _gamesService.GetAll();
            return View(games);
        }
        public IActionResult Details(int Id)
        {
            var game = _gamesService.GetById(Id);
            if (game == null) return NotFound();
            return View(game);
        }

        [HttpGet]
        public IActionResult Create()
        {
            
            CreateGameFormViewModel viewModel = new()
            {
                Categories = _categoriesServices.GetSelectList(),
                Devices = _devicesServices.GetSelectList(),
            };
            return View(viewModel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateGameFormViewModel Model)
        {
            if (!ModelState.IsValid)
            {
                Model.Categories = _categoriesServices.GetSelectList();
                Model.Devices = _devicesServices.GetSelectList();
                return View(Model);
            }
            await _gamesService.Create(Model);
            return RedirectToAction(nameof(Index ));   
        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            var game = _gamesService.GetById(Id);
            if (game == null) return NotFound();
            EditGameFormViewModel viewModel = new()
            {
                Id = game.Id,
                Name = game.Name,
                Description = game.Description,
                CategoryId = game.CategoryId,
                SelectedDevices = game.Devices.Select(d => d.DeviceId).ToList(),
                Categories = _categoriesServices.GetSelectList(),
                Devices = _devicesServices.GetSelectList(),
                CurrentCover = game.Cover,

            };
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EditGameFormViewModel Model)
        {
            if (!ModelState.IsValid)
            {
                Model.Categories = _categoriesServices.GetSelectList();
                Model.Devices = _devicesServices.GetSelectList();
                return View(Model);
            }
            var game =await _gamesService.Update(Model);
            if(game is null) return BadRequest();

            return RedirectToAction(nameof(Index));
        }
        [HttpDelete]
        public IActionResult Delete(int Id)
        {
            var isDeleted =  _gamesService.Delete(Id);
            
            return isDeleted? Ok() :BadRequest();
        }

    }
}
